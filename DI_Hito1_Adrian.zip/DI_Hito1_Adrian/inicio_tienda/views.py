from django.shortcuts import render

# Create your views here.
def inicio_tienda(request):
    return render(request, 'inicio_tienda.html', {})