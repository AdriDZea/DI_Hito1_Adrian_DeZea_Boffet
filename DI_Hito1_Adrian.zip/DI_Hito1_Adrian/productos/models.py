from django.db import models

# Create your models here.
class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    precio = models.CharField(max_length=100)
    descripcion = models.TextField()
    valoracion = models.FilePathField(path="/img")
    imagen = models.FilePathField(path="/img")