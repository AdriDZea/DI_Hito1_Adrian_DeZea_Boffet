from django.urls import path
from . import views

urlpatterns = [
    path("", views.producto_index, name="producto_index"),
    path("<int:pk>/", views.producto_detail, name="producto_detail"),
]